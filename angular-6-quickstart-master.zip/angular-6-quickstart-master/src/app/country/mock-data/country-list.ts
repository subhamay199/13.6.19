import { CountryModel } from "../country-model/country";

export const MockDataCountryList: any[] = [
    { name: 'Japan', capital: 'Tokyo' },
    { name: 'Philippines', capital: '1' },
    { name: 'South Korea', capital: 'Seoul' },
    { name: 'France', capital: 'Paris' },
    { name: 'Italy', capital: 'Rome' }
]