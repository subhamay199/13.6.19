export class CountryModel {
    name: string;
    capital: string;
}


